export default {
  Home: "/pages/home/index",
  Application: "/pages/application/index",
  Backstage: "/pages/backstage/index",
  My: "/pages/my/index",
  Login: "/pages/login/index",
  Register: "/subpackages/pages/register/index",
  Region: "/subpackages/pages/region/index",
  Information: "/subpackages/pages/information/index",
  Message: "/subpackages/pages/message/index",
  leave: "/subpackages/pages/leave/index",
  Announce: "/subpackages/pages/announce/index",
  NameList: "/subpackages/pages/nameList/index"
}
